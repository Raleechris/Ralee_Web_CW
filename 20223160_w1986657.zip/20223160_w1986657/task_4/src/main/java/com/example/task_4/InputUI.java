package com.example.task_4;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class InputUI extends Application{
    @Override
    public void start(Stage primaryStage){
        Label nameLabel = new Label ("Enter Customer Name;");
        TextField nameTextField = new TextField();
        Button submitButton = new Button("Submit");
        Label outputLabel = new Label("Output");

        submitButton.setOnAction(e->{
            String input = nameTextField.getText();
            outputLabel.setText("Hello " + input + "!");
        });

        VBox layout = new VBox (10);
        layout.getChildren().addAll(nameLabel, nameTextField, submitButton);

        Scene scene = new Scene(layout, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Input UI");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}


