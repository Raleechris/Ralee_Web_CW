package task_2;

import java.util.ArrayList;

public class FoodQueue {

    private ArrayList<Customer> customers;
    private int burgerStock;

    private int soldBurgers;

    private int index;

    public FoodQueue() {
        customers = new ArrayList<>();
        burgerStock = 0;
    }

    public FoodQueue(int queueIndex) {
        customers = new ArrayList<>();
        burgerStock = 0;
        index = queueIndex;
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
        burgerStock += customer.getBurgersRequired();
    }

    public Customer removeCustomer(int position) {
        Customer customer = customers.remove(position);
        burgerStock -= customer.getBurgersRequired();
        return customer;
    }

    public int size() {
        return customers.size();
    }

    public boolean isEmpty() {
        return customers.isEmpty();
    }

    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    public int getIndex() {
        return index;
    }
    public Customer getCustomer(int index) {
        return customers.get(index);
    }


    public void addBurgers(int burgersToAdd) {
        burgerStock += burgersToAdd;
    }

    public void addSoldBurgers(int soldCount) {
        soldBurgers += soldCount;
    }

    public int getSoldBurgers() {
        return soldBurgers;
    }

    @Override
    public String toString() {
        String output= "";
        for (Customer customer: customers) {
            output+= customer.toString();
            output+= ";";
        }
        return output;
    }

}