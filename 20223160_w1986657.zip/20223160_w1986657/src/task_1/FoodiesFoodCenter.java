package task_1;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class FoodiesFoodCenter {

    private static String[] cashier1 = new String[2];

    private static String[] cashier2 = new String[3];

    private static String[] cashier3 = new String[5];

    private static final int MAX_BURGERS = 50;

    static final int BURGER_STOCK_WARNING_LIMIT=10;

    private static final int MAX_BURGERS_PER_CUSTOMER = 5;

    private static int burgerStock = MAX_BURGERS;

    private static int burgersOnHold = 0;

    public static void main(String[] args) {
        Arrays.fill(cashier1,"empty");
        Arrays.fill(cashier2,"empty");
        Arrays.fill(cashier3,"empty");

        String option;
        Scanner scanner = new Scanner(System.in);
        do {
            displayMenu();
            option =  scanner.nextLine();;
            // Consume newline character
            switch (option) {
                case "100":
                    viewAllQues();
                    break;
                case "101":
                    viewEmptyQueues();
                    break;
                case "102":
                    addCustomerToTheQueue();
                    break;
                case "103":
                    removeCustomerFromQueue();
                    break;
                case "104":
                    removeServedCustomerFromQueue();
                    break;
                case "105":
//                    viewSortedCustomers();
                    break;
                case "106":
                    storeProgramData();
                    break;
                case "107":
                    loadProgramData();
                    break;
                case "108":
                    viewBurgerStock();
                    break;
                case "109":
                    addBurgersToStock();
                    break;
                case "999":
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (!option.equals("999"));
    }

    private static void displayMenu() {
        System.out.println("");
        System.out.println("========== Foodies Fave Food Center ==========");
        System.out.println("100 or VFQ: View all Queues");
        System.out.println("101 or VEQ: View all Empty Queues");
        System.out.println("102 or ACQ: Add customer to a Queue");
        System.out.println("103 or RCQ: Remove a customer from a Queue (From a specific location)");
        System.out.println("104 or PCQ: Remove a served customer");
        System.out.println("105 or VCS: View Customers Sorted in alphabetical order");
        System.out.println("106 or SPD: Store Program Data into file");
        System.out.println("107 or LPD: Load Program Data from file");
        System.out.println("108 or STK: View Remaining burgers Stock");
        System.out.println("109 or AFS: Add burgers to Stock");
        System.out.println("999 or EXT: Exit the Program");
        System.out.println("==============================================");
        System.out.print("Enter an option: ");
    }

    // ------------------- 100 viewAllQues ------------------------------

    private static void viewAllQues(){
        System.out.println("*****************");
        System.out.println("*   Cashiers    *");
        System.out.println("*****************");

        for (int i = 0; i < cashier3.length; i++) {
            System.out.print(" ");
            if(i<cashier1.length){
                printQueueElement(cashier1[i]);
            }else{
                System.out.print("  -  ");
            }
            if(i<cashier2.length){
                printQueueElement(cashier2[i]);
            }else{
                System.out.print("  -  ");
            }
            if(i<cashier3.length){
                printQueueElement(cashier3[i]);
            }
            System.out.println("      ");

        }
        System.out.println("X-Not Occupied   O-Occupied");

    }

    // ------------------- 101 viewEmptyQueues ---------------------------

    private static void viewEmptyQueues() {
        List<String> emptyQueues = getEmptyQueues();
        if (emptyQueues.isEmpty()) {
            System.out.println("No empty queues found.");//test case no 2.4
        } else {
            System.out.println("Empty queues:");//test case no 2.1, 2.2, 2.3
            {
                for (String queueName : emptyQueues) {
                    System.out.println(queueName);
                }
            }
        }
    }

    // ------------------- 102 addCustomerToTheQueue ---------------------

    private static void addCustomerToTheQueue() {
        if (!isAnyQueueAvailable()){
            System.out.println("No queues are available at the moment");//test case no 3.8
        } else {
            if ((burgerStock-burgersOnHold) >= MAX_BURGERS_PER_CUSTOMER) {
                int queueNumber = inputQueueNumber("ADD");
                String customerName = inputCustomerName();
                int queueIndex = getSmallestQueueIndex(queueNumber);
                String [] queue = getQueueByQueueNumber(queueNumber);
                queue[queueIndex] = customerName;

                burgersOnHold += MAX_BURGERS_PER_CUSTOMER;

                System.out.println("Customer added to the queue successfully.");//test case no 3.2
                System.out.println("Queue Number: "+ queueNumber);
                System.out.println("Customer Name : "+ customerName);

                if((burgerStock-burgersOnHold) <= BURGER_STOCK_WARNING_LIMIT){
                    System.out.println("Warning: Available Burger Stock Reached the minimum warning limit of "+BURGER_STOCK_WARNING_LIMIT);//test case no 3.10
                    System.out.println("Please add burgers");
                }
            } else {
                System.out.println("Insufficient burger stock. Cannot add customer.");//test case no 3.9
            }
        }

    }

    // ------------------- 103 removeCustomerFromQueue -------------------

    private static void removeCustomerFromQueue(){
        if(areAllQueuesEmpty()){
            System.out.println("All queues are empty");
        }else {
            int queueNumber = inputQueueNumber("REMOVE");
            int queueIndex = inputQueueIndex(queueNumber);
            shiftElementsToLeft(queueNumber, queueIndex);
            burgersOnHold -= MAX_BURGERS_PER_CUSTOMER;
            System.out.println("Customer removed from the queue successfully.");//test case no 4.4
            System.out.println("Queue Number: "+ queueNumber + " | Queue Index: "+queueIndex);;
        }
    }

    // ------------------- 104 removeServedCustomerFromQueue -------------

    private static void removeServedCustomerFromQueue(){
        if(areAllQueuesEmpty()){
            System.out.println("All queues are empty");//test case no5.4
        }else {
            int queueNumber = inputQueueNumber("REMOVE");
            int queueIndex = 0;
            shiftElementsToLeft(queueNumber, queueIndex);
            burgersOnHold -= MAX_BURGERS_PER_CUSTOMER;
            burgerStock -= MAX_BURGERS_PER_CUSTOMER;
            System.out.println("Served Customer removed from the queue successfully.");//test case no 5.1
            System.out.println("Queue Number: "+ queueNumber);
        }
    }

    // ------------------- //TODO - 105 viewSortedCustomers --------------


    // ------------------- 106 storeProgramData --------------------------
    private static void storeProgramData(){
        try{
            BufferedWriter writer= new BufferedWriter(new FileWriter("program_data.txt"));

            writer.write(Arrays.toString(cashier1));
            writer.newLine();
            writer.write(Arrays.toString(cashier2));
            writer.newLine();
            writer.write(Arrays.toString(cashier3));
            writer.close();

            System.out.println("Program data stored successfully.");//test case no 7.1
        } catch (IOException e){
            System.out.println("An error occurred while storing the program data");
        }
    }

    // ------------------- 107 loadProgramData --------------------------

    private static void loadProgramData(){
        try{
            BufferedReader reader = new BufferedReader(new FileReader("program_data.txt"));

            String line;
            if((line = reader.readLine()) != null){
                cashier1 = parseQueue(line);
            }

            if((line = reader.readLine()) != null){
                cashier2 = parseQueue(line);
            }

            if((line = reader.readLine()) != null){
                cashier3 = parseQueue(line);
            }
            reader.close();

            System.out.println("Program data loaded successfully.");//test case no 8.1
        } catch (IOException e){
            System.out.println("An error occurred while loading the program data.");
        }
    }

    private static String[] parseQueue(String line){
        line = line.trim();
        line = line.substring(1, line.length() -1);
        String [] elements = line.split(", ");
        int length = elements.length;
        String[] queue = new String[length];
        for (int i = 0; i< length; i++){
            queue[i] = elements[i];
        }
        return queue;
    }


    // ------------------- viewBurgerStock -------------------------------

    private static void viewBurgerStock(){
        System.out.println("Remaining burgers stock: " + burgerStock);//test case no 9.1
        System.out.println("Burgers stock on Hold: " + burgersOnHold);//test case no 9.1
    }

    // ------------------- addBurgersToStock -----------------------------

    private static void addBurgersToStock() {
        int burgersToAdd = inputBurgerStock();
        burgerStock += burgersToAdd;
        System.out.println("Burgers added to the stock. New stock: " + burgerStock); //test case no 10.1
    }

    // ------------------- user inputs -----------------------------------
    private static int inputQueueIndex(int queueNumber){
        String[] queue = getQueueByQueueNumber(queueNumber);
        Scanner scanner = new Scanner(System.in);
        int queueIndex = -1;
        boolean isValidInput = false;

        do {
            System.out.print("Enter the queue position(index) [0-"+(queue.length-1)+"]");
            if (scanner.hasNextInt()) {
                queueIndex = scanner.nextInt();
                if (queueIndex >= 0 && queueIndex <= (queue.length-1)) {
                    if(queue[queueIndex].equals("empty")){
                        System.out.println("Selected location is empty");//test case no 4.10
                    }else {
                        isValidInput = true;
                    }
                }else {
                    System.out.println("Invalid input! Queue index must be between 0 and "+(queue.length-1));//test case 4.8
                }
            }else{
                System.out.println("Invalid input! Please enter a valid integer.");//test case no 4.9
                scanner.next(); // Clear the invalid input from the scanner buffer
            }
        }while (!isValidInput);
        return queueIndex;
    }

    private static int inputQueueNumber(String option){
        Scanner scanner = new Scanner(System.in);
        int queueNumber = -1;

        boolean isValidInput = false;
        do {
            System.out.print("Enter the queue number (1 / 2 / 3): ");//test case 4.5
            if (scanner.hasNextInt()) {
                queueNumber = scanner.nextInt();
                if (queueNumber >= 1 && queueNumber <= 3) {
                    if (option.equals("ADD")){
                        if (getSmallestQueueIndex(queueNumber) != -1){
                            isValidInput = true;
                        }else {
                            System.out.println("Queue " + queueNumber+ " is full. Enter Different Queue Number" ); // test case no 4.4
                        }
                    }else if (option.equals("REMOVE")){
                        if (getSmallestQueueIndex(queueNumber) != 0){
                            isValidInput = true;
                        }else {
                            System.out.println("Queue " + queueNumber+ " is empty. Enter Different Queue Number" ); //test case no 4.3
                        }
                    }
                } else {
                    System.out.println("Invalid input! Queue number must be between 1 and 3."); //test case 4.1
                }
            } else {
                System.out.println("Invalid input! Please enter a valid integer.");//test case 4.2
                scanner.next(); // Clear the invalid input from the scanner buffer
            }
        } while (!isValidInput);

        System.out.println("Selected queue number: " + queueNumber);
        return queueNumber;
    }

    private static String inputCustomerName(){
        Scanner scanner = new Scanner(System.in);
        String customerName;

        boolean isValidInput = false;
        do {
            System.out.print("Enter the customer name: ");//test case no 3.6
            customerName = scanner.nextLine();

            if (customerName.trim().isEmpty()) {
                System.out.println("Invalid input! Customer name cannot be empty.");//test case no 3.7
            } else {
                isValidInput = true;
            }
        } while (!isValidInput);

        System.out.println("Customer name: " + customerName);

        return customerName;

    }

    private static int inputBurgerStock(){
        Scanner scanner = new Scanner(System.in);
        int burgersToAdd = 0;
        boolean isValidInput = false;
        do {
            System.out.print("Enter the number of burgers to add: ");//test case no 10.1
            if (scanner.hasNextInt()) {
                burgersToAdd = scanner.nextInt();
                if(burgerStock + burgersToAdd <= MAX_BURGERS){
                    isValidInput =true;
                }else {
                    System.out.println("Burger Stock is exceeding the maximum limit of "+MAX_BURGERS);//test case no 10.2
                }
            }else {
                System.out.println("Invalid input! Please enter a valid integer.");//test case no 10.3
                scanner.next(); // Clear the invalid input from the scanner buffer
            }

        }while (!isValidInput);

        return burgersToAdd;
    }

    // ------------------- common methods --------------------------------

    private static void printQueueElement(String element){
        if(element.equals("empty")){
            System.out.print("  X  "); // X-Not Occupied
        }else{
            System.out.print("  O  "); // O-Occupied
        }
    }

    private static int getSmallestQueueIndex(int queueNumber){
        int index = -1;
        String[] queue = getQueueByQueueNumber(queueNumber);
        for (int i = 0; i < queue.length; i++) {
            if(queue[i].equals("empty")){
                index = i;
                break;
            }
        }
        return index;
    }

    private static String[] getQueueByQueueNumber(int queueNumber){
        String[] queue = new String[5];
        switch (queueNumber){
            case 1 : {
                queue = cashier1;
                break;
            }
            case 2 :{
                queue = cashier2;
                break;
            }
            case 3 :{
                queue = cashier3;
                break;
            }
        }
        return queue;
    }

    private static List<String> getEmptyQueues() {
        List<String> emptyQueueNames = new ArrayList<>();

        if(cashier1[0].equals("empty")){
            emptyQueueNames.add("Cashier-1");
        }
        if(cashier2[0].equals("empty")){
            emptyQueueNames.add("Cashier-2");
        }
        if(cashier3[0].equals("empty")){
            emptyQueueNames.add("Cashier-3");
        }

        return  emptyQueueNames;

    }

    private static boolean isAnyQueueAvailable(){
        return (getSmallestQueueIndex(1) != -1) ||
                (getSmallestQueueIndex(2) != -1) ||
                (getSmallestQueueIndex(3) != -1);
    }

    private static boolean areAllQueuesEmpty(){
        return (getSmallestQueueIndex(1) == 0) &&
                (getSmallestQueueIndex(2) == 0) &&
                (getSmallestQueueIndex(3) == 0);
    }

    private static void shiftElementsToLeft(int queueNumber, int startIndex) {
        String[] queue = getQueueByQueueNumber(queueNumber);
        for (int i = startIndex; i < queue.length - 1; i++) {
            queue[i] = queue[i + 1];
        }
        queue[queue.length - 1] = "empty";
    }
}
