package task_3;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class FoodiesFoodCenter {

    private static FoodQueue cashier1 = new FoodQueue(1);
    private static FoodQueue cashier2 = new FoodQueue(2);
    private static FoodQueue cashier3 = new FoodQueue(3);
    private static FoodQueue waitingQueue = new FoodQueue(4);
    private static final int[] MAX_CUSTOMERS = {2, 3, 5};

    private static final int MAX_BURGERS = 50;

    static final int BURGER_STOCK_WARNING_LIMIT = 10;

//    private static final int MAX_BURGERS_PER_CUSTOMER = 5;

    private static int burgerStock = MAX_BURGERS;

    private static int burgersOnHold = 0;

    public static void main(String[] args) {

        String option;
        Scanner scanner = new Scanner(System.in);
        do {
            displayMenu();
            option = scanner.nextLine();
            ;
            // Consume newline character
            switch (option) {
                case "100":
                    viewAllQues();
                    break;
                case "101":
                    viewEmptyQueues();
                    break;
                case "102":
                    addCustomerToTheQueue();
                    break;
                case "103":
                    removeCustomerFromQueue();
                    break;
                case "104":
                    removeServedCustomerFromQueue();
                    break;
                case "105":
//                    viewSortedCustomers();
                    break;
                case "106":
                    storeProgramData();
                    break;
                case "107":
                    loadProgramData();
                    break;
                case "108":
                    viewBurgerStock();
                    break;
                case "109":
                    addBurgersToStock();
                    break;
                case "110":
                    viewIncome();
                    break;
                case "999":
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (!option.equals("999"));
    }

    private static void displayMenu() {
        System.out.println("");
        System.out.println("========== Foodies Fave Food Center ==========");
        System.out.println("100: View all Queues");
        System.out.println("101: View all Empty Queues");
        System.out.println("102: Add customer to a Queue");
        System.out.println("103: Remove a customer from a Queue (From a specific location)");
        System.out.println("104: Remove a served customer");
        System.out.println("105: View Customers Sorted in alphabetical order");
        System.out.println("106: Store Program Data into file");
        System.out.println("107: Load Program Data from file");
        System.out.println("108: View Remaining burgers Stock");
        System.out.println("109: Add burgers to Stock");
        System.out.println("110: View income");
        System.out.println("999: Exit the Program");
        System.out.println("==============================================");
        System.out.print("Enter an option: ");
    }

    // ------------------- 100 viewAllQues ------------------------------

    private static void viewAllQues() {
        System.out.println("*****************");
        System.out.println("*   Cashiers    *");
        System.out.println("*****************");

        for (int i = 0; i < MAX_CUSTOMERS[2]; i++) {
            System.out.print(" ");
            if (i < MAX_CUSTOMERS[0]) {
                if ((i + 1) <= cashier1.size()) {
                    printQueueElement("not_empty");
                } else {
                    printQueueElement("empty");
                }
            } else {
                System.out.print("  -  ");
            }

            if (i < MAX_CUSTOMERS[1]) {
                if ((i + 1) <= cashier2.size()) {
                    printQueueElement("not_empty");
                } else {
                    printQueueElement("empty");
                }
            } else {
                System.out.print("  -  ");
            }


            if ((i + 1) <= cashier3.size()) {
                printQueueElement("not_empty");
            } else {
                printQueueElement("empty");
            }

            System.out.println("      ");
        }
        System.out.println("X-Not Occupied   O-Occupied");

    }

    // ------------------- 101 viewEmptyQueues ---------------------------

    private static void viewEmptyQueues() {
        List<String> emptyQueues = getEmptyQueues();
        if (emptyQueues.isEmpty()) {
            System.out.println("No empty queues found.");
        } else {
            System.out.println("Empty queues:");
            {
                for (String queueName : emptyQueues) {
                    System.out.println(queueName);
                }
            }
        }
    }

    // ------------------- 102 addCustomerToTheQueue ---------------------

    private static void addCustomerToTheQueue() {
        String firstName = inputName("first");//test case 3.11, 3.12
        String secondName = inputName("second");//test case 3.13
        int burgersRequired = inputBurgers();

        if ((burgerStock - burgersOnHold) >= burgersRequired) {
            Customer customer = new Customer(firstName, secondName, burgersRequired);
            FoodQueue foodQueue = getNextQueue();
            foodQueue.addCustomer(customer);

            burgersOnHold += burgersRequired;
            if (!isAnyQueueAvailable()) {
                System.out.println("*****************");
                System.out.println("No queues are available at the moment");//test case 3.19
                System.out.println("Customer added to the waiting queue.");//test case 3.19
                System.out.println("Customer Name : " + customer.getFullName());//test case 3.19
            } else {
                System.out.println("*****************");
                System.out.println("Customer added to the queue successfully.");//test case 3.14
                System.out.println("Queue Number: " + foodQueue.getIndex());//test case 3.14
                System.out.println("Customer Name : " + customer.getFullName());//test case 3.14
            }

            if ((burgerStock - burgersOnHold) <= BURGER_STOCK_WARNING_LIMIT) {
                System.out.println("*****************");
                System.out.println("Warning: Available Burger Stock Reached/pass the minimum warning limit of " + BURGER_STOCK_WARNING_LIMIT);//test case 3.15
                System.out.println("Please add burgers");//test case 3.15
            }
        } else {
            System.out.println("Insufficient burger stock. Cannot add customer.");//test case 3.9
        }



    }

    // ------------------- 103 removeCustomerFromQueue -------------------

    private static void removeCustomerFromQueue() {
        if (areAllQueuesEmpty()) {
            System.out.println("All queues are empty");//test case no 4.4
        } else {
            int queueNumber = inputQueueNumber("REMOVE");
            FoodQueue foodQueue = getQueueByQueueNumber(queueNumber);
            int queueIndex = inputQueueIndex(queueNumber);
            burgersOnHold -= foodQueue.getCustomer(queueIndex).getBurgersRequired();
            foodQueue.removeCustomer(queueIndex);
            System.out.println("Customer removed from the queue successfully.");//test case no 4.6
            System.out.println("Queue Number: " + queueNumber + " | Queue Index: " + queueIndex);//test case no 4.6
            ;
        }
    }

    // ------------------- 104 removeServedCustomerFromQueue -------------
    private static void removeServedCustomerFromQueue() {
        if (areAllQueuesEmpty()) {
            System.out.println("All queues are empty");
        } else {
            int queueNumber = inputQueueNumber("REMOVE");
            FoodQueue foodQueue = getQueueByQueueNumber(queueNumber);
            int queueIndex = 0;
            int burgersSold = foodQueue.getCustomer(queueIndex).getBurgersRequired();
            burgersOnHold -= burgersSold;
            burgerStock -= burgersSold;
            foodQueue.addSoldBurgers(burgersSold);
            if(waitingQueue.size()>0){
                foodQueue.removeCustomer(queueIndex);
                System.out.println("Served Customer removed from the queue successfully.");//test case no 5.1
                System.out.println("Queue Number: " + queueNumber);//test case no 5.1

                Customer nextCustomer = waitingQueue.getCustomer(0);
                foodQueue.addCustomer(nextCustomer);
                waitingQueue.removeCustomer(nextCustomer);
                System.out.println("*****************");
                System.out.println("Next customer in the waiting queue  added successfully.");//test case no 5.6
                System.out.println("Customer Name : " + nextCustomer.getFullName());//test case no 5.6
                System.out.println("Queue Number: " + queueNumber);//test case no 5.6
            }else {
                foodQueue.removeCustomer(queueIndex);
                System.out.println("Served Customer removed from the queue successfully.");//test case no 5.5
                System.out.println("Queue Number: " + queueNumber);//test case no 5.5
            }

        }
    }

    // ------------------- //TODO - 105 viewSortedCustomers --------------


    // ------------------- 106 storeProgramData --------------------------

    private static void storeProgramData() {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("program_data_02.txt"));

            writer.write(cashier1.toString());
            writer.newLine();
            writer.write(cashier2.toString());
            writer.newLine();
            writer.write(cashier3.toString());
            writer.newLine();
            writer.write(waitingQueue.toString());
            writer.close();

            System.out.println("Program data stored successfully.");//test case no 7.1
        } catch (IOException e) {
            System.out.println("An error occurred while storing the program data");
        }
    }

    // ------------------- 107 loadProgramData --------------------------

    private static void loadProgramData() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("program_data_02.txt"));

            String line;
            if ((line = reader.readLine()) != null) {
                cashier1 = parseQueue(line);
            }

            if ((line = reader.readLine()) != null) {
                cashier2 = parseQueue(line);
            }

            if ((line = reader.readLine()) != null) {
                cashier3 = parseQueue(line);
            }
            if ((line = reader.readLine()) != null) {
                waitingQueue = parseQueue(line);
            }
            reader.close();

            System.out.println("Program data loaded successfully.");//test case no 8.1
        } catch (IOException e) {
            System.out.println("An error occurred while loading the program data.");
        }
    }

    private static FoodQueue parseQueue(String line) {
        FoodQueue queue = new FoodQueue();
        line = line.trim();
//        line = line.substring(1, line.length() - 1);
        String[] customers = line.split(";");
        for (String el : customers) {
            String[] customerString = el.split(",");
            Customer customer = new Customer(customerString[0], customerString[1], Integer.parseInt(customerString[2]));
            queue.addCustomer(customer);
        }

        return queue;
    }

    // ------------------- 108 viewBurgerStock -------------------------------
    private static void viewBurgerStock() {
        System.out.println("Remaining burgers stock: " + burgerStock);//test case no 9.1
        System.out.println("Burgers stock on Hold: " + burgersOnHold);//test case no 9.1
    }

    // ------------------- 109 addBurgersToStock -----------------------------

    private static void addBurgersToStock() {
        int burgersToAdd = inputBurgerStock();
        burgerStock += burgersToAdd;
        System.out.println("Burgers added to the stock. New stock: " + burgerStock);//test case no 10.1
    }

    // ------------------- 110 viewIncome --------------------------------

    private static void viewIncome() {
        int burgerPrice = 650;
        int q1Income = cashier1.getSoldBurgers() * burgerPrice;
        int q2Income = cashier2.getSoldBurgers() * burgerPrice;
        int q3Income = cashier3.getSoldBurgers() * burgerPrice;
        System.out.println("Income from queue 01: " + q1Income);//test case 11.
        System.out.println("Income from queue 02: " + q2Income);//test case 11.
        System.out.println("Income from queue 03: " + q3Income);//test case 11.
        System.out.println("Total Income : " + (q1Income + q2Income + q3Income));//test case 11.
    }

    // ------------------- user inputs -----------------------------------

    private static String inputName(String option) {
        Scanner scanner = new Scanner(System.in);
        String name;

        boolean isValidInput = false;
        do {
            System.out.print("Enter the " + option + " name: ");//test case no 14.1
            name = scanner.nextLine();

            if (name.trim().isEmpty() || name.trim().contains(" ")
                    || name.trim().contains(",") || name.trim().contains(";") || name.trim().contains("@")
            ) {
                System.out.println("Invalid input! " + option + " name cannot be empty and have space/special characters");//test case 3.11, 3.12
            } else {
                isValidInput = true;
            }
        } while (!isValidInput);

        System.out.println(option + " name: " + name);

        return name;

    }

    private static int inputBurgers() {
        Scanner scanner = new Scanner(System.in);
        int burgerCount = 0;

        boolean isValidInput = false;
        do {
            System.out.print("Enter the number of required burgers: ");//test case 3.17
            if (scanner.hasNextInt()) {
                burgerCount = scanner.nextInt();
                if (burgerCount == 0) {
                    System.out.print("Burgers required should be greater than zero");//test case 3.18
                } else if (burgerCount > 0 && burgerCount <= (burgerStock - burgersOnHold)) {
                    isValidInput = true;
                } else {
                    System.out.println("Not enough burgers in the stock. Add more burgers");//test case 3.17
                }
            } else {
                System.out.println("Invalid input! Please enter a valid integer.");
                scanner.next(); // Clear the invalid input from the scanner buffer
            }
        } while (!isValidInput);

        System.out.println("Entered burger count: " + burgerCount);
        return burgerCount;
    }

    private static int inputQueueNumber(String option) {
        Scanner scanner = new Scanner(System.in);
        int queueNumber = -1;

        boolean isValidInput = false;
        do {
            System.out.print("Enter the queue number (1 / 2 / 3): ");//test case 3.1
            if (scanner.hasNextInt()) {
                queueNumber = scanner.nextInt();
                if (queueNumber >= 1 && queueNumber <= 3) {
                    if (option.equals("ADD")) {
                        if (getSmallestQueueIndex(queueNumber) != -1) {
                            isValidInput = true;
                        } else {
                            System.out.println("Queue " + queueNumber + " is full. Enter Different Queue Number");//test case 3.4
                        }
                    } else if (option.equals("REMOVE")) {
                        if (getSmallestQueueIndex(queueNumber) != 0) {
                            isValidInput = true;
                        } else {
                            System.out.println("Queue " + queueNumber + " is empty. Enter Different Queue Number");
                        }
                    }
                } else {
                    System.out.println("Invalid input! Queue number must be between 1 and 3.");
                }
            } else {
                System.out.println("Invalid input! Please enter a valid integer.");
                scanner.next(); // Clear the invalid input from the scanner buffer
            }
        } while (!isValidInput);

        System.out.println("Selected queue number: " + queueNumber);
        return queueNumber;
    }

    private static int inputQueueIndex(int queueNumber) {
        FoodQueue queue = getQueueByQueueNumber(queueNumber);
        Scanner scanner = new Scanner(System.in);
        int queueIndex = -1;
        boolean isValidInput = false;

        do {
            System.out.print("Enter the queue position(index) [0-" + (queue.size() - 1) + "]");//test case no 13.1
            if (scanner.hasNextInt()) {
                queueIndex = scanner.nextInt();
                if (queueIndex >= 0 && queueIndex <= (queue.size() - 1)) {
                    isValidInput = true;
                } else {
                    System.out.println("Invalid input! Queue index for this queue must be between 0 and " + (queue.size() - 1));//test case no 13.2
                }
            } else {
                System.out.println("Invalid input! Please enter a valid integer.");//test case no 13.3
                scanner.next(); // Clear the invalid input from the scanner buffer
            }
        } while (!isValidInput);
        return queueIndex;
    }

    private static int inputBurgerStock() {
        Scanner scanner = new Scanner(System.in);
        int burgersToAdd = 0;
        boolean isValidInput = false;
        do {
            System.out.print("Enter the number of burgers to add: ");
            if (scanner.hasNextInt()) {
                burgersToAdd = scanner.nextInt();
                if (burgerStock + burgersToAdd <= MAX_BURGERS) {
                    isValidInput = true;
                } else {
                    System.out.println("Burger Stock is exceeding the maximum limit of " + MAX_BURGERS);//test case no 12.1
                }
            } else {
                System.out.println("Invalid input! Please enter a valid integer.");//test case no 12.2
                scanner.next(); // Clear the invalid input from the scanner buffer
            }

        } while (!isValidInput);

        return burgersToAdd;
    }

    // ------------------- common methods --------------------------------

    private static FoodQueue getNextQueue() {
        FoodQueue foodQueue = null;

        if (!isAnyQueueAvailable()) {
            foodQueue = waitingQueue;
        }else {
            int cashier1RemainingLength = MAX_CUSTOMERS[0] - cashier1.size();
            int cashier2RemainingLength = MAX_CUSTOMERS[1] - cashier2.size();
            int cashier3RemainingLength = MAX_CUSTOMERS[2] - cashier3.size();

            if (cashier1RemainingLength > 0 && cashier1.size() <= cashier2.size() && cashier1.size() <= cashier3.size()) {
                foodQueue = cashier1;
            } else if (cashier2RemainingLength > 0 && cashier2.size() <= cashier3.size()) {
                foodQueue = cashier2;
            } else if (cashier3RemainingLength > 0) {
                foodQueue = cashier3;
            }
        }


        return foodQueue;
    }

    private static void printQueueElement(String element) {
        if (element.equals("empty")) {
            System.out.print("  X  "); // X-Not Occupied
        } else {
            System.out.print("  O  "); // O-Occupied
        }
    }

    private static List<String> getEmptyQueues() {
        List<String> emptyQueueNames = new ArrayList<>();

        if (cashier1.size() == 0) {
            emptyQueueNames.add("Cashier-1");
        }
        if (cashier2.size() == 0) {
            emptyQueueNames.add("Cashier-2");
        }
        if (cashier3.size() == 0) {
            emptyQueueNames.add("Cashier-3");
        }

        return emptyQueueNames;

    }

    private static int getSmallestQueueIndex(int queueNumber) {
        int index = 0;
        FoodQueue queue = getQueueByQueueNumber(queueNumber);
        if (queue.size() > 0) {
            index = queue.size();
        }
        return index;
    }

    private static FoodQueue getQueueByQueueNumber(int queueNumber) {
        FoodQueue queue = null;
        switch (queueNumber) {
            case 1: {
                queue = cashier1;
                break;
            }
            case 2: {
                queue = cashier2;
                break;
            }
            case 3: {
                queue = cashier3;
                break;
            }
        }
        return queue;
    }

    private static boolean isAnyQueueAvailable() {
        return (cashier1.size() < MAX_CUSTOMERS[0]) ||
                (cashier2.size() < MAX_CUSTOMERS[1]) ||
                (cashier3.size() < MAX_CUSTOMERS[2]);
    }

    private static boolean areAllQueuesEmpty() {
        return (cashier1.isEmpty() && cashier2.isEmpty() && cashier3.isEmpty());
    }

}
