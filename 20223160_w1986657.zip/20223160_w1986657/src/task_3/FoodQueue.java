package task_3;

import java.util.ArrayList;

public class FoodQueue {

    private ArrayList<Customer> customers;
    private int soldBurgers;

    private int index;

    public FoodQueue() {
        customers = new ArrayList<>();
    }

    public FoodQueue(int queueIndex) {
        customers = new ArrayList<>();
        index = queueIndex;
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public void removeCustomer(int position) {
        customers.remove(position);
    }

    public void removeCustomer(Customer customer) {
        customers.remove(customer);
    }
    public int size() {
        return customers.size();
    }

    public boolean isEmpty() {
        return customers.isEmpty();
    }

    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    public int getIndex() {
        return index;
    }

    public Customer getCustomer(int index) {
        return customers.get(index);
    }



    public void addSoldBurgers(int soldCount) {
        soldBurgers += soldCount;
    }

    public int getSoldBurgers() {
        return soldBurgers;
    }

    @Override
    public String toString() {
        String output = "";
        for (Customer customer : customers) {
            output += customer.toString();
            output += ";";
        }
        return output;
    }

}