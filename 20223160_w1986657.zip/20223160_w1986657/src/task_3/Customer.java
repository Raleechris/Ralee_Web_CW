package task_3;

class Customer implements Comparable<Customer> {
    private String firstName;
    private String lastName;
    private int burgersRequired;


    public Customer(String firstName, String lastName, int burgersRequired) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.burgersRequired = burgersRequired;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public int getBurgersRequired() {
        return burgersRequired;
    }

    @Override
    public int compareTo(Customer other) {
        return this.getFullName().compareTo(other.getFullName());
    }

    @Override
    public String toString() {
        return firstName + "," + lastName + "," + burgersRequired;
    }
}